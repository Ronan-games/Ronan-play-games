## Goal

Get the hero to the flag while avoiding monsters. Clear all three levels and you win the game.

## Controls

Use the arrows to run and space to jump.

## Screenshots

![Title screen](https://raw.githubusercontent.com/joncoop/my-platformer-game/main/screenshots/title_screen.png)

![Play screen](https://raw.githubusercontent.com/joncoop/my-platformer-game/main/screenshots/play_screen.png)
